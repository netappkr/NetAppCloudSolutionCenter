# Headroom
확장 최적화를 위한 Ocean의 주요 기능 중 하나는 **클러스터가 빠른 애플리케이션 확장을 위해 항상 준비되어 있도록 하는 예비 용량**의 버퍼인 headroom 입니다.</br>
특정 양의 리소스(예: vCPU, 메모리 및 GPU)에서 헤드룸을 구성하거나 클러스터의 총 요청 리소스에 대한 백분율로 헤드룸을 지정하면 클러스터는 새 인스턴스가 프로비저닝될 때까지 기다리지 않고 워크로드를 확장할 수 있습니다. </br>
Ocean은 최상의 비용 대비 성능 균형을 제공하기 위해 헤드룸을 동적으로 최적으로 관리합니다. 또는 헤드룸을 수동으로 구성하여 모든 사용 사례를 지원할 수 있습니다.

# 작동 원리
Ocean은 클러스터에 예약되지 않은 워크로드(포드 또는 작업)가 있는지 지속적으로 확인합니다. </br>
예약되지 않은 워크로드가 발견되면 Ocean은 이를 기존 인프라에 배치하는 것을 시뮬레이션합니다. </br>
Ocean은 컴퓨팅 리소스를 미리 저장했기 때문에(즉, 여유 공간이 생성됨) 컨테이너 오케스트레이터는 이러한 리소스를 사용하고 이러한 노드에서 예약되지 않은 워크로드를 즉시 예약할 수 있습니다. </br>
워크로드 확장에 헤드룸이 사용되면 Ocean은 다음 서비스 확장에 대비하여 헤드룸 양의 균형을 맞추기 위해 더 많은 인프라를 프로비저닝할 것입니다. </br>
헤드룸은 자동 또는 수동의 두 가지 메커니즘 중 하나를 사용하여 구성할 수 있습니다. </br>
![DescribeHeadroom](./Images/DescribeHeadroom.png)

# 헤드룸 실습
1. 가상노드그룹에 헤드룸을 설정합니다.
   1. Cluster(Handson-AKS) > Vitual Node Group > VNG Name (userpool)를 클릭하여 VNG를 편집합니다.
   2. Advanced 항목을 드롭다운합니다.
   3. Headroom 항목을 찾고 값을 입력합니다.
   - Reserve: 1
   - CPU (millicpu): 700
   - Memory (MiB): 1000
   - GPUs: 0 
 ![Headroomconfig](./Images/AKSHeadroomconfig.png)
2. Spot Console에서 헤드룸이 적용된것을 확인 합니다.
![viewHeadroom](./Images/viewAKSHeadroom.png)
3. Bastion 서버에서 replica 수를 증가시킵니다.
```bash
kubectl scale deployment --replicas 6 -n ngrinder ngrinder-agent
```
4. Spot 콘솔에서 결과를 확인합니다.
# 결과
- 노드에 해드룸항목이 표시되는것이 보입니다.
- 헤드룸은 Pod의 빠른 확장을 원하는 경우 사용이 적합합니다.
![viewHeadroom](./Images/viewAKSHeadroom2.png)

# 다음과정
Azure Netapp Files에서 볼륨을 추가합니다.</br>
- 다음주제: [Create volume](../AzureNetappFiles/CreateVolmeinAzure.md)
- 추가주제: [Right Sizing](./RightSizing.md)
- 이전주제: [Scaling](./ScalingEvent.md)

# 참조
- [Headroom](https://docs.spot.io/ocean/features/headroom)

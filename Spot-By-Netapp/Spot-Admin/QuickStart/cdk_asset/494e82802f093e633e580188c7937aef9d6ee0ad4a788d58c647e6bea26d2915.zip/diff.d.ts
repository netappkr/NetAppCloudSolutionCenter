export declare function arrayDiff(oldValues: string[], newValues: string[]): {
    adds: string[];
    deletes: string[];
};

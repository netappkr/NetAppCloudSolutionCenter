
Spot Ocean을 통해 ECS workload migration 하기
===============================================
```
들어가기 앞서..
AWS 계정과 ecs를 배포할수 있는 권한이 있는 user가 필요합니다. 자세한 내용은 ecs 생성 단원을 참조하십시요.
Spot 서비스가 AWS 계정과 연동되어 있어야 합니다. 자세한 사항은 spot aws 계정 연결 단원을 참조하십시요.
```
1. AWS ECS Fargate 에 대해 알아 봅니다.
[Amazon Elastic Container Service란 무엇입니까?](https://docs.aws.amazon.com/ko_kr/AmazonECS/latest/developerguide/Welcome.html)
[aws ecs에서 Fargate 사용](https://docs.aws.amazon.com/ko_kr/AmazonECS/latest/developerguide/AWS_Fargate.html)

2. Spot by Netapp 에 대해 알아 봅시다.
[] ()



#workshop 구성도

<img width="80%" height="80%" src="../../images/spot_for_ecs_test_plan.png">
Onprem Ontap 과 AWS FSXontap 간 스냅미러 구성
============================================
## 구성
---
### 구성상세
---
- aws TGW : 네트워크 라우팅
- VPN : Openswan
- vsphere : onpream 가상화 장비


### 구성도
---

<img width="80%" height="80%" src="../images/Snap mirror_conf_between_fsxontap_and_ontap.png">